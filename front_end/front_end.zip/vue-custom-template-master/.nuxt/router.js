import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6dee5a4d = () => interopDefault(import('..\\pages\\course\\index.vue' /* webpackChunkName: "pages/course/index" */))
const _6263f47a = () => interopDefault(import('..\\pages\\login\\index.vue' /* webpackChunkName: "pages/login/index" */))
const _06d10745 = () => interopDefault(import('..\\pages\\register\\index.vue' /* webpackChunkName: "pages/register/index" */))
const _8e7e39ac = () => interopDefault(import('..\\pages\\teacher\\index.vue' /* webpackChunkName: "pages/teacher/index" */))
const _4c0ee816 = () => interopDefault(import('..\\pages\\course\\_id.vue' /* webpackChunkName: "pages/course/_id" */))
const _8b8dd2b4 = () => interopDefault(import('..\\pages\\order\\_id.vue' /* webpackChunkName: "pages/order/_id" */))
const _5887f9e8 = () => interopDefault(import('..\\pages\\pay\\_id.vue' /* webpackChunkName: "pages/pay/_id" */))
const _aabcafdc = () => interopDefault(import('..\\pages\\teacher\\_id.vue' /* webpackChunkName: "pages/teacher/_id" */))
const _b05be7ce = () => interopDefault(import('..\\pages\\video\\_id.vue' /* webpackChunkName: "pages/video/_id" */))
const _3a4b22c8 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/course",
    component: _6dee5a4d,
    name: "course"
  }, {
    path: "/login",
    component: _6263f47a,
    name: "login"
  }, {
    path: "/register",
    component: _06d10745,
    name: "register"
  }, {
    path: "/teacher",
    component: _8e7e39ac,
    name: "teacher"
  }, {
    path: "/course/:id",
    component: _4c0ee816,
    name: "course-id"
  }, {
    path: "/order/:id?",
    component: _8b8dd2b4,
    name: "order-id"
  }, {
    path: "/pay/:id?",
    component: _5887f9e8,
    name: "pay-id"
  }, {
    path: "/teacher/:id",
    component: _aabcafdc,
    name: "teacher-id"
  }, {
    path: "/video/:id?",
    component: _b05be7ce,
    name: "video-id"
  }, {
    path: "/",
    component: _3a4b22c8,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
