<template>
  <div class="cart py-container">
    <!--主内容-->
    <div class="checkout py-container  pay">
      <div class="checkout-tit">
        <h4 class="fl tit-txt"><span class="success-icon"></span><span class="success-info">订单提交成功，请您及时付款！订单号：{{payObj.out_trade_no}}</span>
        </h4>
        <span class="fr"><em class="sui-lead">应付金额：</em><em class="orange money">￥{{payObj.total_fee}}</em></span>
        <div class="clearfix"></div>
      </div>
      <div class="checkout-steps">
        <div class="fl weixin">微信支付</div>
        <div class="fl sao">
          <p class="red">使用微信扫一扫付款</p>
          <div class="fl code">
            <!-- <img id="qrious" src="~/assets/img/erweima.png" alt=""> -->
            <qriously :value="payObj.code_url" :size="338"/>
            <div class="saosao">
              <p>请使用微信扫一扫</p>
              <p>扫描二维码支付</p>
            </div>

          </div>

        </div>
        <div class="clearfix"></div>
        <!-- <p><a href="pay.html" target="_blank">> 其他支付方式</a></p> -->

      </div>
    </div>
  </div>
</template>

<script>
  import order from "../../api/order";

  export default {
    name: "_id",
    asyncData({params, error}) {
      return order.createQRCodeMap(params.id)
        .then(response => {
          return {
            payObj: response.data.data
          }
        })
    },
    data() {
      return {
        timer: ''
      }
    },
    //页面渲染之后执行
    //每隔三秒调用一次查询订单状态
    mounted() {
      //支付成功,清除定时器
      this.timer = setInterval(() => {
        this.getOrderStatus()
      }, 3000)
    },
    methods: {
      getOrderStatus() {
        return order.getOrderStatus(this.payObj.out_trade_no)
          .then(response => {
            if (response.data.success) {
              clearInterval(this.timer)
              this.$message({
                type: 'success',
                message: '支付成功!'
              })
              //跳转到课程详情页面观看视频
              this.$router.push({path: '/course/' + this.payObj.course_id})
            }
          })
      }
    }
  }
</script>
<style scoped>

</style>
