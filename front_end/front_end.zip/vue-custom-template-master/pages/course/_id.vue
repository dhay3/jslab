<template>
  <div id="aCoursesList" class="bg-fa of">
    <section class="container">
      <section class="path-wrap txtOf hLh30">
        <a href="#" title class="c-999 fsize14">首页</a>
        \
        <a href="#" title class="c-999 fsize14">课程列表</a>
        \
        <span class="c-333 fsize14">{{courseWebVo.subjectLevelOne}}</span>
        \
        <span class="c-333 fsize14">{{courseWebVo.subjectLevelTwo}}</span>
      </section>
      <div>
        <article class="c-v-pic-wrap" style="height: 357px;">
          <section class="p-h-video-box" id="videoPlay">
            <img :src="courseWebVo.cover" :alt="courseWebVo.title" class="dis c-v-pic" style="height: 357px;width: 640px">
          </section>
        </article>
        <aside class="c-attr-wrap">
          <section class="ml20 mr15">
            <h2 class="hLh30 txtOf mt15">
              <span class="c-fff fsize24">{{courseWebVo.title}}</span>
            </h2>
            <section class="c-attr-jg">
              <span class="c-fff">价格：</span>
              <b class="c-yellow" style="font-size:24px;">￥{{courseWebVo.price}}</b>
            </section>
            <section class="c-attr-mt c-attr-undis">
              <span class="c-fff fsize14">主讲： {{courseWebVo.teacherName}}&nbsp;&nbsp;&nbsp;</span>
            </section>
<!--            <section class="c-attr-mt of">-->
<!--              <span class="ml10 vam">-->
<!--                <em class="icon18 scIcon"></em>-->
<!--                <a class="c-fff vam" title="收藏" href="#">收藏</a>-->
<!--              </span>-->
<!--            </section>-->
            <section class="c-attr-mt" v-if="courseWebVo.price != 0||isbuy === 0">
              <a href="#" title="立即购买" class="comm-btn c-btn-3" @click="createOrder">立即购买</a>
            </section>
            <section class="c-attr-mt" v-if="courseWebVo.price == 0||isbuy === 1">
              <a href="#" title="立即观看" class="comm-btn c-btn-3">立即观看</a>
            </section>
          </section>
        </aside>
        <aside class="thr-attr-box">
          <ol class="thr-attr-ol clearfix">
            <li>
              <p>&nbsp;</p>
              <aside>
                <span class="c-fff f-fM">购买数</span>
                <br>
                <h6 class="c-fff f-fM mt10">{{courseWebVo.buyCount}}</h6>
              </aside>
            </li>
            <li>
              <p>&nbsp;</p>
              <aside>
                <span class="c-fff f-fM">课时数</span>
                <br>
                <h6 class="c-fff f-fM mt10">{{courseWebVo.lessonNum}}</h6>
              </aside>
            </li>
            <li>
              <p>&nbsp;</p>
              <aside>
                <span class="c-fff f-fM">浏览数</span>
                <br>
                <h6 class="c-fff f-fM mt10">{{courseWebVo.viewCount}}</h6>
              </aside>
            </li>
          </ol>
        </aside>
        <div class="clear"></div>
      </div>
      <!-- /课程封面介绍 -->
      <div class="mt20 c-infor-box">
        <article class="fl col-7">
          <section class="mr30">
            <div class="i-box">
              <div>
                <section id="c-i-tabTitle" class="c-infor-tabTitle c-tab-title">
                  <a name="c-i" class="current" title="课程详情">课程详情</a>
                </section>
              </div>
              <article class="ml10 mr10 pt20">
                <div>
                  <h6 class="c-i-content c-infor-title">
                    <span>课程介绍</span>
                  </h6>
                  <div class="course-txt-body-wrap">
                    <section class="course-txt-body">
                      <!--                      v-html可以输出html标签-->
                      <p v-html="courseWebVo.description">

                      </p>
                    </section>
                  </div>
                </div>
                <!-- /课程介绍 -->
                <div class="mt50">
                  <h6 class="c-g-content c-infor-title">
                    <span>课程大纲</span>
                  </h6>
                  <section class="mt20">
                    <div class="lh-menu-wrap">
                      <menu id="lh-menu" class="lh-menu mt10 mr10">
                        <ul>
                          <!-- 文件目录 -->
                          <li class="lh-menu-stair" v-for="ChapterVideo in ChapterVideoList" :key="ChapterVideo.id">
                            <a href="javascript: void(0)" :title="ChapterVideo.title" class="current-1">
                              <em class="lh-menu-i-1 icon18 mr10"></em>{{ChapterVideo.title}}
                            </a>
                            <ol class="lh-menu-ol" style="display: block;">
                              <li class="lh-menu-second ml30" v-for="video in ChapterVideo.children" :key="video.id">
                                <a :href="'/video/'+video.videoSourceId" :title="video.title" target="_blank">
                                  <span class="fr">
                                    <i class="free-icon vam mr10">免费试听</i>
                                  </span>
                                  <em class="lh-menu-i-2 icon16 mr5">&nbsp;</em>{{video.title}}
                                </a>
                              </li>
                            </ol>
                          </li>
                        </ul>
                      </menu>
                    </div>
                  </section>
                </div>
                <!-- /课程大纲 -->
              </article>
            </div>
          </section>
        </article>
        <aside class="fl col-3">
          <div class="i-box">
            <div>
              <section class="c-infor-tabTitle c-tab-title">
                <a title href="javascript:void(0)">讲师</a>
              </section>
              <section class="stud-act-list">
                <ul style="height: auto;">
                  <li>
                    <div class="u-face">
                      <a href="#">
                        <img :src="courseWebVo.avatar" width="50" height="50" alt>
                      </a>
                    </div>
                    <section class="hLh30 txtOf">
                      <a class="c-333 fsize16 fl" :href="'/teacher/'+courseWebVo.teacherId">{{courseWebVo.teacherName}}</a>
                    </section>
                    <section class="hLh20 txtOf">
                      <span class="c-999">{{courseWebVo.intro}}</span>
                    </section>
                  </li>
                </ul>
              </section>
            </div>
          </div>
        </aside>
        <div class="clear"></div>
      </div>
    </section>
    <!-- /课程详情 结束 -->
    <div class="mt50 commentHtml">
      <div>
        <h6 class="c-c-content c-infor-title" id="i-art-comment">
          <span class="commentTitle">课程评论</span>
        </h6>
        <section class="lh-bj-list pr mt20 replyhtml">
          <ul>
            <li class="unBr">
              <aside class="noter-pic">
                <img width="50" height="50" class="picImg" :src="member.avatar">
              </aside>
              <div class="of">
                <section class="n-reply-wrap">
                  <fieldset>
                    <textarea name="" v-model="comment.content" placeholder="输入您要评论的文字" id="commentContent"></textarea>
                  </fieldset>
                  <p class="of mt5 tar pl10 pr10">
                    <span class="fl "><tt class="c-red commentContentmeg" style="display: none;"></tt></span>
                    <input type="button" @click="addComment()" value="回复" class="lh-reply-btn">
                  </p>
                </section>
              </div>
            </li>
          </ul>
        </section>
        <section class="">
          <section class="question-list lh-bj-list pr">
            <ul class="pr10">
              <li v-for="(comment,index) in data.records" v-bind:key="index">
                <aside class="noter-pic">
                  <img width="50" height="50" class="picImg" :src="comment.avatar">
                </aside>
                <div class="of">
                    <span class="fl">
                    <font class="fsize12 c-blue">
                      {{comment.nickname}}</font>
                    <font class="fsize12 c-999 ml5">评论：</font></span>
                </div>
                <div class="noter-txt mt5">
                  <p>{{comment.content}}</p>
                </div>
                <div class="of mt5">
                  <span class="fr"><font class="fsize12 c-999 ml5">{{comment.gmtCreate}}</font></span>
                </div>
              </li>

            </ul>
          </section>
        </section>

        <!-- 公共分页 开始 -->
        <div class="paging">
          <!-- undisable这个class是否存在，取决于数据属性hasPrevious -->
          <a
            :class="{undisable: !data.hasPrevious}"
            href="#"
            title="首页"
            @click.prevent="gotoPage(1)">首</a>
          <a
            :class="{undisable: !data.hasPrevious}"
            href="#"
            title="前一页"
            @click.prevent="gotoPage(data.current-1)">&lt;</a>
          <a
            v-for="page in data.pages"
            :key="page"
            :class="{current: data.current == page, undisable: data.current == page}"
            :title="'第'+page+'页'"
            href="#"
            @click.prevent="gotoPage(page)">{{ page }}</a>
          <a
            :class="{undisable: !data.hasNext}"
            href="#"
            title="后一页"
            @click.prevent="gotoPage(data.current+1)">&gt;</a>
          <a
            :class="{undisable: !data.hasNext}"
            href="#"
            title="末页"
            @click.prevent="gotoPage(data.pages)">末</a>
          <div class="clear"/>
        </div>
        <!-- 公共分页 结束 -->
      </div>
    </div>
  </div>
</template>

<script>
  import course from "../../api/course";
  import comment from "../../api/comment";
  import cookie from 'js-cookie'
  import login from "../../api/login";
  import order from "../../api/order";

  export default {

    data() {
      return {
        data: {},
        courseId: '',
        courseWebVo: {},
        ChapterVideoList: [],
        comment: {
          content: '',
          courseId: '',
          teacherId: '',
        },
        //初始评论区用户头像
        member: {
          avatar: '',
          id: ''
        },
        courseInfo: {},
        chapterVideoList: [],
        isbuy: false,
      }
    },
    //在页面渲染之前执行
    created() {
      this.initCourseInfo()
      //为登入显示默认头像, 登入后跳转回当前页面
      this.getUserAvatar()
      this.gotoPage(1)

    },
    methods: {
      initCourseInfo() {
        return course.getFrontCourseDetailsByCourseId(this.$route.params.id)
          .then(response => {
            this.courseId = this.$route.params.id
            this.courseWebVo = response.data.data.courseWebVo
            this.ChapterVideoList = response.data.data.ChapterVideoList
            this.isbuy = response.data.data.status
          })
      },
      gotoPage(page) {
        return comment.pageComments(this.$route.params.id, page, 4)
          .then(response => {
            this.data = response.data.data
          })
      },
      addComment() {
        if (cookie.get("user") != null) {
          this.comment.courseId = this.courseId;
          this.comment.teacherId = this.courseWebVo.teacherId
          comment.saveComment(this.comment)
            .then(response => {
              console.log(response)
              this.$message({
                type: 'success',
                message: '评论成功!'
              })
              this.comment.content = ''
              //刷新评论区
              this.gotoPage(1)
            })
        } else {
          this.$message({
            type: 'error',
            message: '未登入!'
          })
        }
      },
      getUserAvatar() {
        //如果用户登入当前域中就会有cookie
        if (!cookie.get("user")) {
          this.member.avatar = 'https://gulied-program.oss-cn-beijing.aliyuncs.com/avatar-boy.gif'
        } else {
          //如果有cookie就会发送请求,请求就会被拦截,加上token通过token查询数据库
          login.getUserInfoByToken()
            .then(response => {
              this.member.avatar = response.data.data.user.avatar
            })
        }
      },
      //生成订单
      createOrder() {
        if (this.member.id === null) {
          this.$message({
            type: 'error',
            message: '未登入!'
          })
        } else {
          order.createOrderByCourseIdMemberId(this.courseId)
            .then(response => {
              this.$router.push({path: '/order/' + response.data.data.orderNo})
            })
        }
      }
    },
  };
</script>
